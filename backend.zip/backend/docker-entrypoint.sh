#!/bin/bash

echo docker entrypoint run

mkdir ./logs

python ./main.py
