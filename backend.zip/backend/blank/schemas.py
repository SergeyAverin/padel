from pydantic import BaseModel


class CreaetBlankDTO(BaseModel):
    user_1: int
    user_2: int
    user_3: int
    user_4: int
